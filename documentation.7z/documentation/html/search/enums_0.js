var searchData=
[
  ['_5fzhv_5facr_5frec_5ftype_805',['_zhv_acr_rec_type',['../zhavam__acrcloud_8h.html#a76f599aaebcb58b8b96c761aa573d034',1,'zhavam_acrcloud.h']]],
  ['_5fzhv_5falsa_5fsnd_5fpcm_5fformat_806',['_zhv_alsa_snd_pcm_format',['../zhavam__alsa_8h.html#adbc3de90a0811e2d7e9d3d794e0b6d92',1,'zhavam_alsa.h']]],
  ['_5fzhv_5fpa_5fsample_5fformat_807',['_zhv_pa_sample_format',['../zhavam__pulse_8h.html#a0c3b19c5dfecce8b7c3f41b7b7df0d78',1,'zhavam_pulse.h']]]
];
