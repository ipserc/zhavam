var searchData=
[
  ['basename',['basename',['../zhavam_8h.html#a12a67e5867cf5abf4575a48f377c2150',1,'zhavam.h']]]
];
