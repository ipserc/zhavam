var searchData=
[
  ['closedevice',['closeDevice',['../zhavam__alsa_8c.html#a381d7f2a196b4fe54a17e72049767002',1,'closeDevice(snd_pcm_t *capture_handle):&#160;zhavam_alsa.c'],['../zhavam__alsa_8h.html#a381d7f2a196b4fe54a17e72049767002',1,'closeDevice(snd_pcm_t *capture_handle):&#160;zhavam_alsa.c']]],
  ['configload',['configLoad',['../zhavam__config_8c.html#a09aa115d33e3e40f03ad234f55e5f25d',1,'configLoad(char *zhvHome, zhavamConf_t *ptZhavamConf):&#160;zhavam_config.c'],['../zhavam__config_8h.html#a09aa115d33e3e40f03ad234f55e5f25d',1,'configLoad(char *zhvHome, zhavamConf_t *ptZhavamConf):&#160;zhavam_config.c']]],
  ['configupdate',['configUpdate',['../zhavam__config_8c.html#ace813b8c21f9ad1a64f16b54292e1f51',1,'configUpdate(zhavamConf_t *ptZhavamConf):&#160;zhavam_config.c'],['../zhavam__config_8h.html#ace813b8c21f9ad1a64f16b54292e1f51',1,'configUpdate(zhavamConf_t *ptZhavamConf):&#160;zhavam_config.c']]],
  ['createzhavamconf',['createZhavamConf',['../zhavam__config_8c.html#a506f6351897117e3949fc66742bdd2cb',1,'createZhavamConf(char *zhvHome, zhavamConf_t *ptZhavamConf):&#160;zhavam_config.c'],['../zhavam__config_8h.html#a506f6351897117e3949fc66742bdd2cb',1,'createZhavamConf(char *zhvHome, zhavamConf_t *ptZhavamConf):&#160;zhavam_config.c']]]
];
