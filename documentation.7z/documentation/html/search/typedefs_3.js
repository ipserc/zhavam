var searchData=
[
  ['zhv_5facr_5frec_5ft',['zhv_acr_rec_t',['../zhavam__acrcloud_8h.html#a604401eec247536d418b5b552ec3b012',1,'zhavam_acrcloud.h']]],
  ['zhv_5falsa_5fsnd_5fpcm_5fformat_5ft',['zhv_alsa_snd_pcm_format_t',['../zhavam__alsa_8h.html#a8310d82b6c440d00f6fba4f7130992fc',1,'zhavam_alsa.h']]],
  ['zhv_5fpa_5fsample_5fformat_5ft',['zhv_pa_sample_format_t',['../zhavam__pulse_8h.html#a0d33a7c007a85aa7b0eea08f9cc4dee5',1,'zhavam_pulse.h']]]
];
