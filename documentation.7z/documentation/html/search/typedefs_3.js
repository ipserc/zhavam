var searchData=
[
  ['zhv_5facr_5frec_5ft_802',['zhv_acr_rec_t',['../zhavam__acrcloud_8h.html#a08c2f86d1605c8d61a2a0ba83aa306b0',1,'zhavam_acrcloud.h']]],
  ['zhv_5falsa_5fsnd_5fpcm_5fformat_5ft_803',['zhv_alsa_snd_pcm_format_t',['../zhavam__alsa_8h.html#a089147b42626f5c40c5c00bc200dfa35',1,'zhavam_alsa.h']]],
  ['zhv_5fpa_5fsample_5fformat_5ft_804',['zhv_pa_sample_format_t',['../zhavam__pulse_8h.html#a1e010de5f562460a547c6497b0826f19',1,'zhavam_pulse.h']]]
];
