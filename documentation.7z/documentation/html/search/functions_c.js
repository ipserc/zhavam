var searchData=
[
  ['opendevice',['openDevice',['../zhavam__alsa_8c.html#a4e261a4ae072b93fe662055aef5cf0ef',1,'openDevice(char *devID, snd_pcm_t **ptr_capture_handle, snd_pcm_hw_params_t **ptr_hw_params):&#160;zhavam_alsa.c'],['../zhavam__alsa_8h.html#a4e261a4ae072b93fe662055aef5cf0ef',1,'openDevice(char *devID, snd_pcm_t **ptr_capture_handle, snd_pcm_hw_params_t **ptr_hw_params):&#160;zhavam_alsa.c']]]
];
