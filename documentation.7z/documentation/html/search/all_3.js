var searchData=
[
  ['capture_50',['capture',['../structalsa_device__t.html#aa3c1b8637f6e472a338f726570a9dd2e',1,'alsaDevice_t']]],
  ['card_51',['card',['../structpulse_device__t.html#affe6cbf17e83fbc044a5f5adb43a8078',1,'pulseDevice_t']]],
  ['catchsigterm_52',['catchSigterm',['../zhavam_8c.html#ab4dbbc3d3898d6d3988023236223b01f',1,'zhavam.c']]],
  ['closedevice_53',['closeDevice',['../zhavam__alsa_8c.html#a381d7f2a196b4fe54a17e72049767002',1,'closeDevice(snd_pcm_t *capture_handle):&#160;zhavam_alsa.c'],['../zhavam__alsa_8h.html#a381d7f2a196b4fe54a17e72049767002',1,'closeDevice(snd_pcm_t *capture_handle):&#160;zhavam_alsa.c']]],
  ['code_54',['code',['../structstatus__t.html#a65aa69098a93d330f9d8af9362623035',1,'status_t']]],
  ['compilation_55',['COMPILATION',['../zhavam_8c.html#a95dfd2336ffecbde0cd51147ae054013',1,'zhavam.c']]],
  ['config_56',['config',['../structzhv_params__t.html#aadde00e0c01172f078246131d26bdace',1,'zhvParams_t']]],
  ['config_2eh_57',['config.h',['../config_8h.html',1,'']]],
  ['configload_58',['configLoad',['../zhavam__config_8c.html#a09aa115d33e3e40f03ad234f55e5f25d',1,'configLoad(char *zhvHome, zhavamConf_t *ptZhavamConf):&#160;zhavam_config.c'],['../zhavam__config_8h.html#a09aa115d33e3e40f03ad234f55e5f25d',1,'configLoad(char *zhvHome, zhavamConf_t *ptZhavamConf):&#160;zhavam_config.c']]],
  ['configupdate_59',['configUpdate',['../zhavam__config_8c.html#ace813b8c21f9ad1a64f16b54292e1f51',1,'configUpdate(zhavamConf_t *ptZhavamConf):&#160;zhavam_config.c'],['../zhavam__config_8h.html#ace813b8c21f9ad1a64f16b54292e1f51',1,'configUpdate(zhavamConf_t *ptZhavamConf):&#160;zhavam_config.c']]],
  ['contact_60',['CONTACT',['../zhavam_8c.html#a8c04334560f245d0b6a7b535b01ae26a',1,'zhavam.c']]],
  ['cost_5ftime_61',['cost_time',['../structacr__data__t.html#a11ea889348eba2f077fb7f96fa7110c1',1,'acr_data_t']]],
  ['createzhavamconf_62',['createZhavamConf',['../zhavam__config_8c.html#a506f6351897117e3949fc66742bdd2cb',1,'createZhavamConf(char *zhvHome, zhavamConf_t *ptZhavamConf):&#160;zhavam_config.c'],['../zhavam__config_8h.html#a506f6351897117e3949fc66742bdd2cb',1,'createZhavamConf(char *zhvHome, zhavamConf_t *ptZhavamConf):&#160;zhavam_config.c']]],
  ['creation_63',['CREATION',['../zhavam_8c.html#a5377827b1fa485632cfad0a97735cd98',1,'zhavam.c']]]
];
