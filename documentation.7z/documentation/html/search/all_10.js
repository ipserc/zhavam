var searchData=
[
  ['readme',['README',['../md__home_ipserc_worspace-2019-09_zhavam__source__r_e_a_d_m_e.html',1,'']]],
  ['rate',['rate',['../structalsa__config__t.html#adf42a979321286885fe5a447d48d14d6',1,'alsa_config_t::rate()'],['../structpulse__config__t.html#adf42a979321286885fe5a447d48d14d6',1,'pulse_config_t::rate()']]],
  ['readme_2emd',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['readzhvparams',['readZhvParams',['../zhavam_8c.html#acc57fcaba42898b8a9244cd57550389e',1,'readZhvParams(int argc, char *argv[]):&#160;zhavam.c'],['../zhavam_8h.html#acc57fcaba42898b8a9244cd57550389e',1,'readZhvParams(int argc, char *argv[]):&#160;zhavam.c']]],
  ['rec_5ftype_5f',['rec_type_',['../structacrcloud__config__s.html#acab2151acf893abdbf15186676363fce',1,'acrcloud_config_s']]],
  ['recognize',['recognize',['../zhavam__acrcloud_8c.html#aea05d2638472cbb8f11978d4cbd9b4ef',1,'recognize(acrcloud_config acrConfig, char *pcm_buffer, int pcm_buffer_len, int nchannels, int sample_rate):&#160;zhavam_acrcloud.c'],['../zhavam__acrcloud_8h.html#aea05d2638472cbb8f11978d4cbd9b4ef',1,'recognize(acrcloud_config acrConfig, char *pcm_buffer, int pcm_buffer_len, int nchannels, int sample_rate):&#160;zhavam_acrcloud.c']]],
  ['rectypedecode',['recTypeDecode',['../zhavam__acrcloud_8c.html#ae2edd432dbb5dd094b9c7515369ef0fb',1,'recTypeDecode(const char *recTypeString):&#160;zhavam_acrcloud.c'],['../zhavam__acrcloud_8h.html#ae2edd432dbb5dd094b9c7515369ef0fb',1,'recTypeDecode(const char *recTypeString):&#160;zhavam_acrcloud.c']]],
  ['rectypestring',['recTypeString',['../zhavam__acrcloud_8c.html#acb21da570ab693cca375d513f27a30e0',1,'recTypeString(zhv_acr_rec_t acrcloud_rec_type):&#160;zhavam_acrcloud.c'],['../zhavam__acrcloud_8h.html#acb21da570ab693cca375d513f27a30e0',1,'recTypeString(zhv_acr_rec_t acrcloud_rec_type):&#160;zhavam_acrcloud.c']]],
  ['release_5fdate',['release_date',['../structmusic__t.html#a1d8ea5d1f0e8f620bbfa1e0367c46b53',1,'music_t']]],
  ['result_5ffrom',['result_from',['../structmusic__t.html#a8fecc734392c3a614b53d926c5338da9',1,'music_t']]],
  ['result_5ftype',['result_type',['../structacr__data__t.html#a8f6ba823098283740ffef07c462f5def',1,'acr_data_t']]]
];
