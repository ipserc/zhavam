var searchData=
[
  ['initacrdatat',['initAcrDataT',['../zhavam__jsonparser_8c.html#a500c6861d2eadc91e6267f6bc174d3e5',1,'initAcrDataT(acr_data_t *acrData):&#160;zhavam_jsonparser.c'],['../zhavam__jsonparser_8h.html#a500c6861d2eadc91e6267f6bc174d3e5',1,'initAcrDataT(acr_data_t *acrData):&#160;zhavam_jsonparser.c']]]
];
