var searchData=
[
  ['capture_729',['capture',['../structalsa_device__t.html#aa3c1b8637f6e472a338f726570a9dd2e',1,'alsaDevice_t']]],
  ['card_730',['card',['../structpulse_device__t.html#affe6cbf17e83fbc044a5f5adb43a8078',1,'pulseDevice_t']]],
  ['code_731',['code',['../structstatus__t.html#a65aa69098a93d330f9d8af9362623035',1,'status_t']]],
  ['config_732',['config',['../structzhv_params__t.html#aadde00e0c01172f078246131d26bdace',1,'zhvParams_t']]],
  ['cost_5ftime_733',['cost_time',['../structacr__data__t.html#a11ea889348eba2f077fb7f96fa7110c1',1,'acr_data_t']]]
];
