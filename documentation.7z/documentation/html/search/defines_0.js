var searchData=
[
  ['alsa_5fpcm_5ffile_860',['ALSA_PCM_FILE',['../zhavam__devices_8h.html#ace20931c548152f1025f7b234cc46444',1,'zhavam_devices.h']]],
  ['author_861',['AUTHOR',['../zhavam_8c.html#a6c8fad838ed64cc67da3f68149009758',1,'zhavam.c']]]
];
