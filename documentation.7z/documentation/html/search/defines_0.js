var searchData=
[
  ['alsa_5fpcm_5ffile',['ALSA_PCM_FILE',['../zhavam__devices_8h.html#ace20931c548152f1025f7b234cc46444',1,'zhavam_devices.h']]]
];
