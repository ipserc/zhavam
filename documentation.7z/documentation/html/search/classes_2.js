var searchData=
[
  ['external_5fmetadata_5ft',['external_metadata_t',['../structexternal__metadata__t.html',1,'']]]
];
