var searchData=
[
  ['external_5fmetadata_5ft_485',['external_metadata_t',['../structexternal__metadata__t.html',1,'']]]
];
