var searchData=
[
  ['access_5fkey_5f',['access_key_',['../structacrcloud__config__s.html#acc7159ad8af66749ef79bac48453a5b1',1,'acrcloud_config_s']]],
  ['access_5fsecret_5f',['access_secret_',['../structacrcloud__config__s.html#a13659b1f0cb78b6d5c1122423b17d0c0',1,'acrcloud_config_s']]],
  ['acrcloud',['acrcloud',['../structzhavam_conf__t.html#af55c73581191ed441fe9fb2f25812e90',1,'zhavamConf_t']]],
  ['acrid',['acrid',['../structmusic__t.html#ae60754453b1fc06d16200f30433310d0',1,'music_t']]],
  ['album',['album',['../structmusic__t.html#ad51092200d669f56a307eda2313709c2',1,'music_t']]],
  ['album_5fid',['album_id',['../structspotify__t.html#a68bf4f96808d8cf117706f4a6dd445a4',1,'spotify_t::album_id()'],['../structdeezer__t.html#a68bf4f96808d8cf117706f4a6dd445a4',1,'deezer_t::album_id()']]],
  ['alsa',['alsa',['../structzhavam_conf__t.html#ab55927af03584e7dc337704c5f6a4686',1,'zhavamConf_t']]],
  ['appname',['appName',['../structzhavam_conf__t.html#a8328fe273170554a9b7e02306c553c15',1,'zhavamConf_t']]],
  ['artist_5fid',['artist_id',['../structspotify__t.html#a93a08575511c116d3372bdaf368aa999',1,'spotify_t::artist_id()'],['../structdeezer__t.html#a93a08575511c116d3372bdaf368aa999',1,'deezer_t::artist_id()']]],
  ['artists',['artists',['../structmusic__t.html#aff035cd5f2b092ea7443b86ce2bdd23e',1,'music_t']]]
];
