var searchData=
[
  ['name_762',['name',['../structitem__t.html#a5ac083a645d964373f022d03df4849c8',1,'item_t::name()'],['../structpulse_device__t.html#a8ad935bcebdd2d69a36e4b9869cddb6a',1,'pulseDevice_t::name()'],['../structsound_device__t.html#a8ad935bcebdd2d69a36e4b9869cddb6a',1,'soundDevice_t::name()'],['../list_8c.html#a7238a84df55719cb7aa3198816633449',1,'NAME():&#160;list.c']]],
  ['next_763',['next',['../structnode.html#a0dc1b6470487aa86d9936e3cab8b95be',1,'node']]],
  ['nogui_764',['nogui',['../structzhv_params__t.html#a8fb47ce0552a09afda99e96f1b7d913f',1,'zhvParams_t']]]
];
