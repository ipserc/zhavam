var searchData=
[
  ['short_5flen',['SHORT_LEN',['../zhavam__devices_8h.html#a05358d0ce35a362ae91a5c991e88b09b',1,'zhavam_devices.h']]],
  ['snd_5fpa_5fstream_5fname',['SND_PA_STREAM_NAME',['../zhavam__pulse_8h.html#ad7279f730ad2ef85409b9fcc90213f7b',1,'zhavam_pulse.h']]],
  ['snd_5fpcm_5fformat_5funknown',['SND_PCM_FORMAT_UNKNOWN',['../zhavam__alsa_8h.html#a48f7ff1288b3d9da4985d88aa8bcddc6',1,'zhavam_alsa.h']]],
  ['status00',['STATUS00',['../zhavam_8h.html#a2e43ab8840122eb3f496752feac3438a',1,'zhavam.h']]],
  ['status01',['STATUS01',['../zhavam_8h.html#a147ee6f71e1472fc3dd7655ebbfd78cb',1,'zhavam.h']]],
  ['status02',['STATUS02',['../zhavam_8h.html#a6b1275f4be41d1104e3c64356ac8623a',1,'zhavam.h']]],
  ['status03',['STATUS03',['../zhavam_8h.html#ac603e4b32cb55437fa0c7fe505ff78ba',1,'zhavam.h']]],
  ['status04',['STATUS04',['../zhavam_8h.html#a6d87e48e3147f818f887648589f93be6',1,'zhavam.h']]],
  ['status05',['STATUS05',['../zhavam_8h.html#ac5451eeb422c9267110a5ecbd0ae3f84',1,'zhavam.h']]],
  ['stdc_5fheaders',['STDC_HEADERS',['../config_8h.html#a550e5c272cc3cf3814651721167dcd23',1,'config.h']]],
  ['str_5ftimelen',['STR_TIMELEN',['../zhavam__errtra_8h.html#aedcdd4cf6ec5d99ff70cf1492e888028',1,'zhavam_errtra.h']]]
];
