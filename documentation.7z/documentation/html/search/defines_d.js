var searchData=
[
  ['value_5fmax_5flen',['VALUE_MAX_LEN',['../zhavam__jsonparser_8h.html#a627c5366b8f52ae4f0dd4b7491bc84f2',1,'zhavam_jsonparser.h']]],
  ['version',['VERSION',['../config_8h.html#a1c6d5de492ac61ad29aec7aa9a436bbf',1,'VERSION():&#160;config.h'],['../zhavam_8h.html#a1c6d5de492ac61ad29aec7aa9a436bbf',1,'VERSION():&#160;zhavam.h']]]
];
