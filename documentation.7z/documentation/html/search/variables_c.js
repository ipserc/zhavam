var searchData=
[
  ['pa_5fsample_5fformat_765',['pa_sample_format',['../structpulse__config__t.html#af108d7a029deb3c3e5c27a2699eed335',1,'pulse_config_t']]],
  ['parent_766',['parent',['../structjsmntok__t.html#a4dafd66c26e6b8acf64d2feba6141bcc',1,'jsmntok_t']]],
  ['pcm_5fbuffer_5fframes_767',['pcm_buffer_frames',['../structalsa__config__t.html#aac164fcdd07df55208bed1c589b31cd1',1,'alsa_config_t::pcm_buffer_frames()'],['../structpulse__config__t.html#aac164fcdd07df55208bed1c589b31cd1',1,'pulse_config_t::pcm_buffer_frames()']]],
  ['pcm_5fdev_768',['pcm_dev',['../structalsa__config__t.html#ac305626445eadb6196418ffb89739d8e',1,'alsa_config_t::pcm_dev()'],['../structpulse__config__t.html#ac305626445eadb6196418ffb89739d8e',1,'pulse_config_t::pcm_dev()']]],
  ['play_5foffset_5fms_769',['play_offset_ms',['../structmusic__t.html#ad210f3b9796c60ebd69c8e7fda65950b',1,'music_t']]],
  ['playcapture_770',['playCapture',['../structalsa_device__t.html#a2f698b653fe9d54b43328a40ea54f2bf',1,'alsaDevice_t']]],
  ['pos_771',['pos',['../structjsmn__parser.html#addcb93d939ffa259ff1d9247bdd590fd',1,'jsmn_parser']]],
  ['prev_772',['prev',['../structnode.html#a530843171ca1a6e033bac999737cb184',1,'node']]],
  ['pulse_773',['pulse',['../structzhavam_conf__t.html#a7e4321760006405679aa41a7db5e1316',1,'zhavamConf_t']]]
];
