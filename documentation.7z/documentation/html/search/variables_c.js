var searchData=
[
  ['pa_5fsample_5fformat',['pa_sample_format',['../structpulse__config__t.html#af108d7a029deb3c3e5c27a2699eed335',1,'pulse_config_t']]],
  ['pabufferattr',['paBufferAttr',['../zhavam__pulse_8c.html#a9b0349d83e048b59dd4aa26acbdaa144',1,'zhavam_pulse.c']]],
  ['parent',['parent',['../structjsmntok__t.html#a4dafd66c26e6b8acf64d2feba6141bcc',1,'jsmntok_t']]],
  ['pasamplespec',['paSampleSpec',['../zhavam__pulse_8c.html#aa5feae6e302671a1fd7088e92201aafc',1,'zhavam_pulse.c']]],
  ['pcm_5fbuffer_5fframes',['pcm_buffer_frames',['../structalsa__config__t.html#aac164fcdd07df55208bed1c589b31cd1',1,'alsa_config_t::pcm_buffer_frames()'],['../structpulse__config__t.html#aac164fcdd07df55208bed1c589b31cd1',1,'pulse_config_t::pcm_buffer_frames()']]],
  ['pcm_5fdev',['pcm_dev',['../structalsa__config__t.html#ac305626445eadb6196418ffb89739d8e',1,'alsa_config_t::pcm_dev()'],['../structpulse__config__t.html#ac305626445eadb6196418ffb89739d8e',1,'pulse_config_t::pcm_dev()']]],
  ['play_5foffset_5fms',['play_offset_ms',['../structmusic__t.html#ad210f3b9796c60ebd69c8e7fda65950b',1,'music_t']]],
  ['playcapture',['playCapture',['../structalsa_device__t.html#a2f698b653fe9d54b43328a40ea54f2bf',1,'alsaDevice_t']]],
  ['pos',['pos',['../structjsmn__parser.html#addcb93d939ffa259ff1d9247bdd590fd',1,'jsmn_parser']]],
  ['prev',['prev',['../structnode.html#a530843171ca1a6e033bac999737cb184',1,'node']]],
  ['pulse',['pulse',['../structzhavam_conf__t.html#a7e4321760006405679aa41a7db5e1316',1,'zhavamConf_t']]]
];
