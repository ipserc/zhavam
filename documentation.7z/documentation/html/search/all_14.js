var searchData=
[
  ['value_5fmax_5flen',['VALUE_MAX_LEN',['../zhavam__jsonparser_8h.html#a627c5366b8f52ae4f0dd4b7491bc84f2',1,'zhavam_jsonparser.h']]],
  ['version',['version',['../structzhv_params__t.html#abc0be3a9d810e3ad1cc6a33b7dc8c83a',1,'zhvParams_t::version()'],['../structstatus__t.html#a81db5ba9b5f1d49a6236610d6b55109d',1,'status_t::version()'],['../config_8h.html#a1c6d5de492ac61ad29aec7aa9a436bbf',1,'VERSION():&#160;config.h'],['../zhavam_8h.html#a1c6d5de492ac61ad29aec7aa9a436bbf',1,'VERSION():&#160;zhavam.h'],['../list_8c.html#a3424fd1405aca79d26aff9ebc2831af6',1,'VERSION():&#160;list.c']]]
];
