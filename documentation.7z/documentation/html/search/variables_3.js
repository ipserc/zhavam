var searchData=
[
  ['deezer',['deezer',['../structexternal__metadata__t.html#ae8bb041abccc5be3995a7a17f0f60741',1,'external_metadata_t']]],
  ['description',['description',['../structpulse_device__t.html#ae3576885b45bc8c1f28714a4fbad4de1',1,'pulseDevice_t::description()'],['../structsound_device__t.html#a4935867aa3557b95ba683c14c2dfa6b5',1,'soundDevice_t::description()']]],
  ['devicenbr',['deviceNbr',['../structalsa_device__t.html#a91086eb046ebae49f1a1f3ea565551bb',1,'alsaDevice_t']]],
  ['devid',['devId',['../structalsa_device__t.html#a81370a607887199ac572424ddb1c6285',1,'alsaDevice_t']]],
  ['devname',['devName',['../structalsa_device__t.html#a5972810040cf8199302d1ff0eab93070',1,'alsaDevice_t']]],
  ['devsubname',['devSubName',['../structalsa_device__t.html#a5af4daf60c35ff848f7d70c85252ed7e',1,'alsaDevice_t']]],
  ['drivercontroller',['driverController',['../structzhavam_conf__t.html#aa7e15e55144a3de5e041dd2c2029bed7',1,'zhavamConf_t']]],
  ['duration_5fms',['duration_ms',['../structmusic__t.html#a5616f06d5386572980532773a090a9e0',1,'music_t']]]
];
