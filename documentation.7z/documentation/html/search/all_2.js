var searchData=
[
  ['basenamelen_48',['BASENAMELEN',['../zhavam_8h.html#a4023d3df4a3cb3602ed231495d445947',1,'zhavam.h']]],
  ['buffer_49',['buffer',['../structzhv_params__t.html#a0e0ff970abe71c59dd1d3334fa840ea6',1,'zhvParams_t']]]
];
