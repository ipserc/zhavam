var searchData=
[
  ['done',['done',['../zhavam__devices_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba9041c40ebd1ff09fe453b594ad748199',1,'zhavam_devices.h']]]
];
