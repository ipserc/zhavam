var searchData=
[
  ['node_5ft_801',['node_t',['../list_8h.html#a7c02633e18d6aa5f58539b75f08753d9',1,'list.h']]]
];
