var searchData=
[
  ['acrcloud_5frecognizer_2eh',['acrcloud_recognizer.h',['../acrcloud__recognizer_8h.html',1,'']]]
];
