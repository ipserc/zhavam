var searchData=
[
  ['acrcloud_5fopt_5frec_5ftype_5fs_808',['ACRCLOUD_OPT_REC_TYPE_S',['../acrcloud__recognizer_8h.html#a072e16590e0902d60d07913a22f5d272',1,'acrcloud_recognizer.h']]]
];
