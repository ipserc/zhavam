var searchData=
[
  ['acr_5fopt_5frec_5faudio',['acr_opt_rec_audio',['../acrcloud__recognizer_8h.html#a072e16590e0902d60d07913a22f5d272a38136bee7822c5810abe421aeecb000f',1,'acrcloud_recognizer.h']]],
  ['acr_5fopt_5frec_5fboth',['acr_opt_rec_both',['../acrcloud__recognizer_8h.html#a072e16590e0902d60d07913a22f5d272a166bbea8b87c78211f4ae4958bdac0c9',1,'acrcloud_recognizer.h']]],
  ['acr_5fopt_5frec_5fhumming',['acr_opt_rec_humming',['../acrcloud__recognizer_8h.html#a072e16590e0902d60d07913a22f5d272a72459ceeee4e6f674358bb62742593e5',1,'acrcloud_recognizer.h']]],
  ['alsa',['ALSA',['../zhavam__config_8h.html#ab40f2289264165b985cd52d63299ef69a0c522143dad872d6af6c3def9773eab0',1,'zhavam_config.h']]]
];
