var searchData=
[
  ['rate_774',['rate',['../structalsa__config__t.html#adf42a979321286885fe5a447d48d14d6',1,'alsa_config_t::rate()'],['../structpulse__config__t.html#adf42a979321286885fe5a447d48d14d6',1,'pulse_config_t::rate()']]],
  ['rec_5ftype_5f_775',['rec_type_',['../structacrcloud__config__s.html#acab2151acf893abdbf15186676363fce',1,'acrcloud_config_s']]],
  ['release_5fdate_776',['release_date',['../structmusic__t.html#a1d8ea5d1f0e8f620bbfa1e0367c46b53',1,'music_t']]],
  ['result_5ffrom_777',['result_from',['../structmusic__t.html#a8fecc734392c3a614b53d926c5338da9',1,'music_t']]],
  ['result_5ftype_778',['result_type',['../structacr__data__t.html#a8f6ba823098283740ffef07c462f5def',1,'acr_data_t']]]
];
