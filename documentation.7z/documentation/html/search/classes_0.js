var searchData=
[
  ['acr_5fdata_5ft_480',['acr_data_t',['../structacr__data__t.html',1,'']]],
  ['acrcloud_5fconfig_5fs_481',['acrcloud_config_s',['../structacrcloud__config__s.html',1,'']]],
  ['alsa_5fconfig_5ft_482',['alsa_config_t',['../structalsa__config__t.html',1,'']]],
  ['alsadevice_5ft_483',['alsaDevice_t',['../structalsa_device__t.html',1,'']]]
];
