var searchData=
[
  ['acr_5fdata_5ft',['acr_data_t',['../structacr__data__t.html',1,'']]],
  ['acrcloud_5fconfig_5fs',['acrcloud_config_s',['../structacrcloud__config__s.html',1,'']]],
  ['alsa_5fconfig_5ft',['alsa_config_t',['../structalsa__config__t.html',1,'']]],
  ['alsadevice_5ft',['alsaDevice_t',['../structalsa_device__t.html',1,'']]]
];
