var searchData=
[
  ['version',['version',['../structzhv_params__t.html#abc0be3a9d810e3ad1cc6a33b7dc8c83a',1,'zhvParams_t::version()'],['../structstatus__t.html#a81db5ba9b5f1d49a6236610d6b55109d',1,'status_t::version()'],['../list_8c.html#a3424fd1405aca79d26aff9ebc2831af6',1,'VERSION():&#160;list.c']]]
];
