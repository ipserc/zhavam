var searchData=
[
  ['metadata_758',['metadata',['../structacr__data__t.html#a1c6b4523b021db8cc91a717151743ce1',1,'acr_data_t']]],
  ['monitor_5fname_759',['monitor_name',['../structpulse_device__t.html#add2b95d02cf089a2f20f0dffd4421443',1,'pulseDevice_t']]],
  ['msg_760',['msg',['../structstatus__t.html#ad4a099401aa857f4982db956c97daedb',1,'status_t']]],
  ['music_761',['music',['../structmetadata__t.html#a909edf44d7f512794031b6ad0197f46d',1,'metadata_t']]]
];
