var searchData=
[
  ['acrcloud_5fconfig',['acrcloud_config',['../acrcloud__recognizer_8h.html#a2b46a87890900d77631cdd53832095db',1,'acrcloud_recognizer.h']]],
  ['acrcloud_5fopt_5frec_5ftype',['ACRCLOUD_OPT_REC_TYPE',['../acrcloud__recognizer_8h.html#a64aaaca6afc14e1517964a73353c09aa',1,'acrcloud_recognizer.h']]]
];
