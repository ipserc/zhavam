var searchData=
[
  ['pulse',['PULSE',['../zhavam__config_8h.html#ab40f2289264165b985cd52d63299ef69a6a0aa0c7f1e82444e7df71dfd7509cac',1,'zhavam_config.h']]]
];
