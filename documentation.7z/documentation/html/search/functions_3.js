var searchData=
[
  ['eerror',['eError',['../zhavam__errtra_8c.html#af12ef037f7d8ab147255f0ccb4aa9319',1,'eError(const char *fmtstr,...):&#160;zhavam_errtra.c'],['../zhavam__errtra_8h.html#af12ef037f7d8ab147255f0ccb4aa9319',1,'eError(const char *fmtstr,...):&#160;zhavam_errtra.c']]]
];
