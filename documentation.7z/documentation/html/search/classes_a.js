var searchData=
[
  ['zhavamconf_5ft',['zhavamConf_t',['../structzhavam_conf__t.html',1,'']]],
  ['zhvparams_5ft',['zhvParams_t',['../structzhv_params__t.html',1,'']]]
];
