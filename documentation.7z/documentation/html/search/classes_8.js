var searchData=
[
  ['pulse_5fconfig_5ft',['pulse_config_t',['../structpulse__config__t.html',1,'']]],
  ['pulsedevice_5ft',['pulseDevice_t',['../structpulse_device__t.html',1,'']]]
];
