var searchData=
[
  ['zhv_5facr_5fopt_5frec_5fint',['zhv_acr_opt_rec_int',['../zhavam__acrcloud_8c.html#ab3faf390f7ab49855f65df5626d0a218',1,'zhavam_acrcloud.c']]],
  ['zhv_5facr_5fopt_5frec_5fstr',['zhv_acr_opt_rec_str',['../zhavam__acrcloud_8c.html#a9fe804c76b31871b03d5ba256b2ba0c0',1,'zhavam_acrcloud.c']]],
  ['zhv_5falsa_5fsnd_5fpcm_5fformat_5fint',['zhv_alsa_snd_pcm_format_int',['../zhavam__alsa_8c.html#ad0b9b866ad179cd8021689d72837afc6',1,'zhavam_alsa.c']]],
  ['zhv_5falsa_5fsnd_5fpcm_5fformat_5fstr',['zhv_alsa_snd_pcm_format_str',['../zhavam__alsa_8c.html#ac3244c5e797742d270f31e04c8f868f9',1,'zhavam_alsa.c']]],
  ['zhv_5fdrivercontroller_5fstr',['zhv_driverController_str',['../zhavam__config_8c.html#a84e1340017d89bf883381363136fd9be',1,'zhavam_config.c']]],
  ['zhv_5fpa_5fsample_5fformat_5fint',['zhv_pa_sample_format_int',['../zhavam__pulse_8c.html#a20bf4a78a9cf5f398216ba7262a3e85d',1,'zhavam_pulse.c']]],
  ['zhv_5fpa_5fsample_5fformat_5fstr',['zhv_pa_sample_format_str',['../zhavam__pulse_8c.html#a018e0a702cd2cf3b8a21ec72a57ddb32',1,'zhavam_pulse.c']]]
];
