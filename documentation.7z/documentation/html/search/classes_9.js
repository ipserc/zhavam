var searchData=
[
  ['sounddevice_5ft',['soundDevice_t',['../structsound_device__t.html',1,'']]],
  ['spotify_5ft',['spotify_t',['../structspotify__t.html',1,'']]],
  ['status_5ft',['status_t',['../structstatus__t.html',1,'']]]
];
