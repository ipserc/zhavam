var searchData=
[
  ['sounddevice_5ft_495',['soundDevice_t',['../structsound_device__t.html',1,'']]],
  ['spotify_5ft_496',['spotify_t',['../structspotify__t.html',1,'']]],
  ['status_5ft_497',['status_t',['../structstatus__t.html',1,'']]]
];
