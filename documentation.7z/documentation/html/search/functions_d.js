var searchData=
[
  ['readzhvparams_691',['readZhvParams',['../zhavam_8c.html#acc57fcaba42898b8a9244cd57550389e',1,'readZhvParams(int argc, char *argv[]):&#160;zhavam.c'],['../zhavam_8h.html#acc57fcaba42898b8a9244cd57550389e',1,'readZhvParams(int argc, char *argv[]):&#160;zhavam.c']]],
  ['recognize_692',['recognize',['../zhavam__acrcloud_8c.html#aea05d2638472cbb8f11978d4cbd9b4ef',1,'recognize(acrcloud_config acrConfig, char *pcm_buffer, int pcm_buffer_len, int nchannels, int sample_rate):&#160;zhavam_acrcloud.c'],['../zhavam__acrcloud_8h.html#aea05d2638472cbb8f11978d4cbd9b4ef',1,'recognize(acrcloud_config acrConfig, char *pcm_buffer, int pcm_buffer_len, int nchannels, int sample_rate):&#160;zhavam_acrcloud.c']]],
  ['rectypedecode_693',['recTypeDecode',['../zhavam__acrcloud_8c.html#ae2edd432dbb5dd094b9c7515369ef0fb',1,'recTypeDecode(const char *recTypeString):&#160;zhavam_acrcloud.c'],['../zhavam__acrcloud_8h.html#ae2edd432dbb5dd094b9c7515369ef0fb',1,'recTypeDecode(const char *recTypeString):&#160;zhavam_acrcloud.c']]],
  ['rectypestring_694',['recTypeString',['../zhavam__acrcloud_8c.html#acb21da570ab693cca375d513f27a30e0',1,'recTypeString(zhv_acr_rec_t acrcloud_rec_type):&#160;zhavam_acrcloud.c'],['../zhavam__acrcloud_8h.html#acb21da570ab693cca375d513f27a30e0',1,'recTypeString(zhv_acr_rec_t acrcloud_rec_type):&#160;zhavam_acrcloud.c']]]
];
