var searchData=
[
  ['head',['head',['../structlist.html#ad9513cdd45a8c7a0435f6fb6cb8a3fd6',1,'list']]],
  ['help',['help',['../structzhv_params__t.html#a545363392790133c5dec1fd9e2cb279d',1,'zhvParams_t']]],
  ['host_5f',['host_',['../structacrcloud__config__s.html#a2af5eca9d36fd8a4b5cfc8ec40bf85d1',1,'acrcloud_config_s']]],
  ['hwdev',['hwDev',['../structalsa_device__t.html#aea06e110ce64ed20d1fd92c97271f5a7',1,'alsaDevice_t']]]
];
